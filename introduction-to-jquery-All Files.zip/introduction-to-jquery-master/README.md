##Introduction to jQuery
-------------------------------
###Instructions

To use these lesson files, clone this repo into your web server's root folder. Typically this folder would be known as <code>'www'</code> as in the case of Apache, however this may differ, depending on your server environment. 
